# BỐI CẢNH DỰ ÁN: đọc file này trước tiên

File này gom lại những gì đã biết và đã quyết định, để người hoặc agent tiếp nhận không phải tìm hiểu lại từ đầu. Cập nhật ngày 15/10/2026.

## 1. Dự án là gì

- Viết lại **sách ngữ pháp và đọc hiểu tiếng Nhật cho người Việt** của Hizashi.
- Khung CHÍNH là `book_reading` (bản cũ, viết tháng 4/2026). Cốt lõi của bản này là mô phỏng cách người bản ngữ xử lý câu theo dòng, dựa trên `tu_lieu/book_reading/research/research.md`.
- `hizashi_dich_cau/resource` (01–02/2026) là bản làm trước: khóa N5 theo 25 bài Minna, viết cho ứng dụng. **Chỉ dùng làm tư liệu.**
- Thư mục `lam_lai_grammar` (không đóng gói) là giáo trình ngữ pháp theo Minna, không liên quan đến dự án này.
- Quy trình mẫu là sách phát âm `book_hatsuon`, đã hoàn thành Bản Học sinh. Mẫu văn phong của sách đó nằm ở `tu_lieu/mau_sach_phat_am/`.

## 2. Đã quyết định

1. Giữ **39 bài**, đánh số như bản cũ, để khớp với bài tập JSON. **Không động đến bài tập**: sách chỉ đưa phương pháp luyện, không viết bài tập.
2. Viết **Bản Học sinh trước**. Việc có làm Bản Giáo viên hay không còn để mở.
3. Cốt lõi là **thứ tự hiểu theo mẫu ngữ pháp** (chủ biên nhấn mạnh). Mô hình 3 tín hiệu và nguyên tắc "Đóng gói nội dung ngay. Để ngỏ vai trò cho đến đuôi câu" được trình bày trong `KHUNG_SACH.md`.
4. Giai đoạn 0, kiểm chứng nền lý thuyết, sẽ do chủ biên làm ở nơi khác. Chỉ dẫn nằm trong `HUONG_NGHIEN_CUU.md`.

## 3. Quy tắc văn phong (bắt buộc, rút từ sách phát âm)

- **Tiếng Việt PHẢI có dấu đầy đủ.** Subagent hay viết thiếu dấu, nên phải kiểm tra lại.
- **Giọng sách tham khảo khách quan.** Không xưng "bạn", "mình", "chúng ta". Dùng "người Việt", "người học". Không viết câu cảm thán kiểu quảng cáo như "Chúc mừng!" hay "Tin tốt:".
- Có lý thuyết thật, khiến người đọc thấy "à, hóa ra là thế": đặt vấn đề hoặc nghịch lý, rồi giải thích cơ chế. Nhưng **không dùng ô chen ngang** kiểu "> **Hóa ra:**".
- Dẫn dắt kiểu báo cáo nhưng bớt hàn lâm: Vấn đề → Cơ sở → Phân tích "Tiếng Nhật: / Tiếng Việt: / Cơ chế lỗi:" → Kết luận và hàm ý.
- **Quá trình tự động của não** viết ở thể bị động hoặc vô thức: "bị xếp vào…", "được hiểu thành…". **Hành động có ý thức của người học** viết chủ động: "chia khối", "đánh dấu", "đối chiếu".
- Tiền đề chung: khó khăn không phải do luyện ít, mà do **luyện tập chưa có chủ đích**.
- Tác giả người Việt ghi **đủ họ tên có dấu**, ví dụ Lê Thị Huyền Trang. Không viết tắt.
- Dùng **TTT** cho 普通形, không dùng "plain form".
- Phải giữ ba kỹ thuật **chia khối, dự đoán, đóng gói 🔒** trong mọi bài. Bảng phân tích phải có bước đóng gói khi gặp danh từ + trợ từ.

## 4. Quy tắc chính xác

- Các file nguồn phần lớn do AI tổng hợp và **có lỗi**. Chỉ dùng làm tư liệu.
- **Không đưa con số không có nguồn.** Mọi câu kiểu "nghiên cứu cho thấy…" phải kiểm chứng bằng bài gốc hoặc bản tóm tắt. Không kiểm chứng được thì bỏ.
- Ví dụ tiếng Nhật phải đúng ngữ pháp và nghĩa. Bản dịch tách thành **dịch theo khối** (có gắn nhãn) và **dịch tự nhiên**.
- Chỗ còn nghi ngờ đánh dấu `<!-- CẦN KIỂM CHỨNG: ... -->`.

## 5. Những điều đã phát hiện về tư liệu

- `book_reading/content/index.md` **chỉ liệt kê đến Bài 33** và ghi sai thứ tự Bài 27–32. Thực tế có 39 bài; tiêu đề đúng nằm trong từng file `lesson_XX.md`, và đã được ghi lại trong `KHUNG_SACH.md` mục 4.
- Phần 0 cũ (`part_00_method.md`) ghi "4 kỹ thuật", còn CLAUDE.md ghi 3 kỹ thuật. Phần 0 cũ còn xưng "bạn" và dẫn Miller (1956) "5–9 đơn vị", con số này cần sửa theo Cowan (2001).
- Bản cũ có những câu dịch gượng: "Về phần tôi thì, là sinh viên", "Tôi trà CŨNG uống".
- Bốn file `research/lesson_00_*.md` giống hệt bản trong `hizashi_dich_cau` (đã so mã băm), nên chỉ đóng gói một bản.
- Nội dung về thứ tự hiểu đã có, nhưng nằm rải rác ở các bài:
  - phó từ báo đuôi câu (もし…たら, ぜんぜん…ない): Bài 36, 23;
  - đuôi câu đổi cách hiểu: Bài 20 (10 kiểu đuôi TTT), 28 (trích dẫn);
  - đuôi câu đổi vai "ai làm gì": Bài 24, 25, 37, 33;
  - nối câu: Bài 6, 29–32, 39;
  - diễn giải: Bài 20 (んです), 35, 27.
- `mau_sach_phat_am/su_khac_biet_am_thanh.md` là **mẫu về lối viết**, nhưng mục 4.2 của nó **sai về nguồn**. Không lấy nội dung trong đó.

## 6. Cấu trúc gói này

```
book_dokkai/
├── BOI_CANH.md            ← file này
├── README.md
├── KHUNG_SACH.md          ← khung sách, mô hình 3 tín hiệu, mục lục 39 bài, lộ trình
├── HUONG_NGHIEN_CUU.md    ← Giai đoạn 0: luận điểm, nguồn ứng viên, rà research.md
├── research/              ← (trống) nơi đặt kết quả kiểm chứng, nen_tang_doc_hieu.md
├── student/               ← (trống) nơi đặt Bản Học sinh
└── tu_lieu/
    ├── CLAUDE_hizashi_book.md     ← quy tắc dự án gốc
    ├── book_reading/              ← BẢN SAO ĐẦY ĐỦ của hizashi_book/book_reading
    │   ├── research/              ← research.md, setsuzoku.md, lesson_00_* (có 2 bản thẩm định chuyên gia)
    │   ├── review/                ← các báo cáo thẩm định cũ
    │   ├── content/
    │   │   ├── index.md, part_00_method.md, METHODOLOGY_AND_SYSTEM.md, part_02_sentence_structures.md
    │   │   ├── exercises_common/  ← spec bài tập, spec luyện dịch, script convert và validate
    │   │   └── part_01 … part_05/ ← lesson_XX.md, draft/, exercises/ (JSON trắc nghiệm),
    │   │                            exercises_draft/ (md nháp), practice/ (JSON luyện dịch)
    │   ├── reading_collection/    ← bộ bài đọc: READING_SPEC.md, readings.db, readings_*.json, bản nháp N3
    │   ├── grammar_202604280043.json
    │   └── viewer.py
    ├── hizashi_dich_cau/          ← khung N5, đối chiếu Minna, grammar_all_lessons.md
    ├── ban_tai_cau_truc_nhan_thuc/ ← bản sách "Tái Cấu Trúc Nhận Thức" 12/2025 (PDF, docx, JSON cấu trúc; tai_cau_truc.json có Lời tựa viết lại)
    ├── nghien_cuu_khac/           ← các báo cáo nghiên cứu khác của hizashi_book: Hán-Việt → On'yomi,
    │                                chuyển âm, phát âm Tokyo, biến âm, sokuon, shadowing, kanji; kèm bản tóm tắt
    └── mau_sach_phat_am/          ← HOI_DONG_SACH, BANG_THUAT_NGU, Chương 0, Chương 1, su_khac_biet_am_thanh
```

`hizashi_dich_cau/research.md` giống hệt `book_reading/research/research.md` (đã so mã băm), nên chỉ giữ một bản.

Không đóng gói: `__pycache__`, `lam_lai_grammar` (giáo trình theo Minna, không liên quan), file `.env`.
